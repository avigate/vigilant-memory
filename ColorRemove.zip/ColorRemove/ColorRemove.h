#ifndef _COLORREMOVE_H
#define  _COLORREMOVE_H

#define UCHR unsigned char
#define US    unsigned short
#define TOLEFT 1
#define TORIGHT 0 
//#define NULL 0



/******global variables access for  any function*****/
typedef struct tagBMPHEAD
{
	char   ID[2];					//1
	long   FileSize;					//3
	short  Reserved[2];				//7
	long   HeaderSize;				//11
	long   InfoSize;					//15
	long   Width;					//19
	long   Height;					//23
	short  BiPlanes;					//27
	short  bits;						//29
	long   biCompression;			//31
	long   biSizeImage;				//35
	long   biXPelsPerMeter;			//39
	long   biYPelsPerMeter;			//43
	long   biClrUsed;				//47
	long   biClrImportant;			//51

}BMPHEAD;


typedef struct tagRGB
{

	UCHR blue;
	UCHR green;
	UCHR red;
	//UCHR filler;

}RGBQ;


typedef struct centerK
{

	UCHR blue;
	UCHR green;
	UCHR red;
	UCHR filler;

}CEN;



#endif