#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<memory.h>
#include<math.h>
#include "ColorRemove.h"

   
   int main()
   {

	   //Read Input Image
	   FILE *fp=fopen("test.bmp","rb");

	   //Open Output Image
	   FILE  *fq=fopen("ColorSeperate.bmp","wb");

       long Width = 0 ;

	   long Height = 0 ;

	   BMPHEAD head ;

	   RGBQ *Raster = NULL;

	   RGBQ* InvertRaster = NULL;

	   CEN *center = NULL ; 

	   double *Euclidean = NULL ;

	   UCHR* IndexRaster = NULL ;

	   long *Max = NULL ;

	   long *NearestCount = NULL ;

	  //Read Header of 54 Bytes
	  fread(&head,sizeof(BMPHEAD),1,fp) ;
	 
	  //Assign width value from extracted header
	  Width = head.Width ;	  

	  //Assign height value from extracted header
	  Height = head.Height ;
	  
	  //Write the same header information to output Img
	  fwrite( &head ,sizeof(BMPHEAD) ,1 ,fq ) ;
       
      //Irrelevant hence commented
	  //center=( CEN* )malloc( sizeof(CEN) * 256 ) ; 

	  //Buffer allocation for input Image 	  
	  Raster = ( RGBQ* )malloc(sizeof(RGBQ) * head.Width * head.Height) ;

	  //Buffer allocation for output Image.(Name inverse raster has been given as we may invert the image)
	 
	  InvertRaster = ( RGBQ* )malloc( sizeof(RGBQ) * head.Width * head.Height ) ;
	 
	  fread( Raster ,sizeof( RGBQ ) ,head.Width*head.Height ,fp ) ;


	  //Change the color's: This is main portion of processing buffer

	  for(int i = 0 ; i <= head.Height - 1 ; i++ )

	    for(int j = 0 ; j<= head.Width - 1 ; j++ )
		  {
    
			Raster[i*Width + j].blue = 255 - Raster[i*Width + j].blue;

			Raster[i*Width + j].green = 255 - Raster[i*Width + j].green;

			Raster[i*Width + j].red = 255 - Raster[i*Width + j].red;
		  }
	  //Write the processes buffer to Image	        
	  fwrite( Raster, sizeof(RGBQ) , head.Width*head.Height, fq ) ;
	  
	  //close the file 
	  fclose( fq ) ;

	  return(0);

	  }
  

  
 